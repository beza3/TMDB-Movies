# Import necessary libraries
import pandas as pd

# Load the dataset
df = pd.read_csv('tmdb-movies.csv')  # Replace 'your_dataset.csv' with the actual file path

# Check the structure of the dataset
print(df.info())

# Handle multiple values separated by pipe characters
# For 'genres' column
df['genres'] = df['genres'].str.split('|')

# For 'cast' column (ignoring odd characters)
# No cleaning is needed as per your instructions, but you may want to split it if needed
# df['cast'] = df['cast'].str.split('|')

# Check for missing values
print(df.isnull().sum())

# Handle missing values if necessary (based on your analysis goals)
# df = df.dropna()  # Example: Drop rows with missing values

# Explore the first few rows of the dataset
print(df.head())
